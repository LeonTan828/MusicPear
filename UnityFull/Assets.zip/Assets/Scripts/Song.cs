﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Song : MonoBehaviour
{
    private string name;
    private string artist;
    private string album;
}
