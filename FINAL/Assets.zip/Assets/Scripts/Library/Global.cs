﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// This class focuses on the controlling/moderating the following library functions:
// Initializing the user's playlists
// Creating and Displaying the user's playlists (as the player creates a playlist, the list of Playlists is updated)
// Delete a user created playlist
// Viewing the songs inside a playlist (populating the list of song buttons through the SongListControlLibrary)
// Deleting songs from a playlist 

public class Global : MonoBehaviour
{
    [SerializeField]
    InputField newPlaylistInput; // This takes the user's input when creating a new playlist 
    [SerializeField]
    ButtonListControl playlistList; // This controls the list of playlist buttons 
    [SerializeField]
    SongListControlLibrary songListControl; // This controls the list of song buttons

    public GameObject panel;    // This panel corresponds with the playlist panel 
                                //(so when a playlist is selected, a panel displaying the name and option to delete playlist is displayed)
    public Text currentPlaylistName;

    public string[] allSongs; // A displayable array of strings for displaying / populating the song buttons

    public List<Playlist> allPlaylists; // All the playlists the user as created so far 

    private void Start()
    {
        // Initialize playlist 
        if (UserGlobal.Instance != null)
        {
            allPlaylists = UserGlobal.Instance.userPlaylists;
        } else
        {
            allPlaylists = new List<Playlist>();
        }

    }

    // This returns the list of Playlist Objects corresponding to all the playlists the user has created
    public List<Playlist> getPlaylists()
    {
        return allPlaylists;
    }

    // This converts the List<playlist> allPlaylists into a displayable array of strings 
    public string[] getPlaylistList()
    {
        string[] temp = new string[0]; // Initialize empty playlist

        // If there are playlists in the list, then reinitialize playlists
        if (allPlaylists.Count != 0)
        {
            string[] tempNew = new string[allPlaylists.Count];

            for (int i = 0; i < allPlaylists.Count; i++)
            {
                tempNew[i] = allPlaylists[i].getPlaylistName();
            }

            temp = tempNew;
        }
        return temp;
    }

    // This method creates a local playlist
    public void createNewPlaylist()
    {
        string newPlaylistName = newPlaylistInput.text;

        if (newPlaylistName.Equals(""))
        {
            newPlaylistName = "<Untitiled>";
        }

        Playlist newPlaylist = new Playlist(newPlaylistName); // Constructs a new playlist object

        allPlaylists.Add(newPlaylist); // Adds to list of playlists 

    }

    // This method deletes a playlist from all the playlists the user has created
    public void deletePlaylist()
    {
        // Find the index that the playlist you want to delete is at
        int deleteIndex = -1;

        for (int i = 0; i < allPlaylists.Count; i++)
        {
            if (allPlaylists[i].getPlaylistName().Equals(currentPlaylistName.text))
            {
                if (deleteIndex < 0)
                {
                    deleteIndex = i;
                }
                
            }
        }

        songListControl.deleteAllSongs(allPlaylists[deleteIndex]); // Removes all songs from the playlist
        allPlaylists.RemoveAt(deleteIndex); // Deletes the playlist
    }

    // This method deletes the song from a playlist 
    public void deleteSongFromPlaylist()
    {
        // Find the index that the playlist you want to delete the song from
        int deleteIndex = -1;

        for (int i = 0; i < allPlaylists.Count; i++)
        {
            if (allPlaylists[i].getPlaylistName().Equals(currentPlaylistName.text))
            {
                if (deleteIndex < 0)
                {
                    deleteIndex = i;
                }

            }
        }
        songListControl.deleteSong(allPlaylists[deleteIndex]);
    }

    // This changes the panel state
    public void ChangePanelState(bool state)
    {
        panel.SetActive(state); // Reveals playlist panel
    }

    public Playlist findPlaylist(string name)
    {
        for (int i = 0; i < allPlaylists.Count; i++)
        {
            if (allPlaylists[i].getPlaylistName().Equals(name))
            {
                return allPlaylists[i];

            }
        }
        return null;
    }
}
