﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SongListControlLibrary : MonoBehaviour
{
    [SerializeField]
    private GameObject songButtonTemplate; // Initialized through unity inspector

    public GameObject panel;
    public GameObject hidePlaylistPanel;

    public Text SongName;
    
    private List<Song> playlistSongs;

    private string[] allSongs;

    private List<GameObject> songButtons;
    int currCount;

    public Playlist currPlaylist;

    public void Start()
    {

        allSongs = new string[]{
             
        };
        currCount = allSongs.Length;
        // This locally holds the current number of songs (used to update list if user deletes any song and needs to update number of songs 

        
        songButtons = new List<GameObject>(); // Create a new list of buttons that will display the songs (song -> button)
        
    }

    public void buttonClicked(string selectedSongText)
    {
        SongName.text = selectedSongText;
        panel.SetActive(true);
        hidePlaylistPanel.SetActive(false);
    }

    public void ChangePanelState(bool state)
    {
        panel.SetActive(state); // Reveals playlist panel
    }

    public void updateCurrentPlaylist(Playlist playlist)
    {
        string[] temp;
        // Locally assign the playlist & get songs in List form
        playlistSongs = playlist.getSongList(); // This locally stores a reference to the playlist that was selected (paramater) 
        temp = new string[playlistSongs.Count]; // This will hold all the songs in string format 

        // If the playlist has no songs, return /end
        if (temp.Length == 0)
        {
            return;
        }

        // Arrange songs into string array
        for (int i = 0; i < temp.Length; i++)
        {
            temp[i] = playlistSongs[i].getSongName();
        }

        allSongs = temp;

        // Updates the list of song buttons by clearing out the current buttons and repopulating 
        if (songButtons.Count > 0)
        {
            foreach (GameObject button in songButtons)
            {
                Destroy(button.gameObject);
            }
            songButtons.Clear();
        }


        foreach (string i in allSongs)
        {
            GameObject button = Instantiate(songButtonTemplate) as GameObject; // This creates a new song button
            button.SetActive(true);

            songButtons.Add(button); // add the button to the button list

            button.GetComponent<SongListButtonLibrary>().SetText(i);

            button.transform.SetParent(songButtonTemplate.transform.parent, false);
            // this will set the parent of the button to the parent of what it is spawning from (in this case, the button list content object)
        }

    }

    public void deleteAllSongs(Playlist playlist)
    {
        // This clears out any previous song buttons that have been displayed
        if (songButtons.Count > 0)
        {
            foreach (GameObject button in songButtons)
            {
                Destroy(button.gameObject);
            }
            songButtons.Clear();
        }
        playlist.clearSongList();

    }

    public void deleteSong(Playlist playlist)
    {
        panel.SetActive(false);

        // if last song, remove everything 
        if (playlist.getNumSongs() == 1)
        {
            deleteAllSongs(playlist);
        } else
        {
            playlist.deleteSongFromPlaylist(SongName.text);
        }

        updateCurrentPlaylist(playlist);
    }
}
