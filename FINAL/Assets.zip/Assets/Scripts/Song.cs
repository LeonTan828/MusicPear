﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// This is the framework for the song object
public class Song
{
    private string name;
    private string artist;
    private string album;
    private string ID;

    public Song(string songName)
    {
        name = songName;
    }

    public Song(string songName, string artist, string ID)
    {
        name = songName;
        artist = artist;
        album = album;
    }
    public string getSongName()
    {
        return name;
    }

}
